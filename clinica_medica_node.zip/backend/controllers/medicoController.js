const db = require('../config/db');

exports.listarMedicos = (req, res) => {
  const sql = 'SELECT * FROM medicos ORDER BY id DESC';

  db.query(sql, (err, results) => {
    if (err) {
      console.error('Erro ao listar médicos:', err);
      return res.status(500).json({ erro: 'Erro ao listar médicos' });
    }

    res.json(results);
  });
};

exports.criarMedico = (req, res) => {
  const { nome, especialidade } = req.body;

  if (!nome || !especialidade) {
    return res.status(400).json({ erro: 'Preencha nome e especialidade' });
  }

  const sql = 'INSERT INTO medicos (nome, especialidade) VALUES (?, ?)';

  db.query(sql, [nome, especialidade], (err, result) => {
    if (err) {
      console.error('Erro ao criar médico:', err);
      return res.status(500).json({ erro: 'Erro ao criar médico' });
    }

    res.status(201).json({
      mensagem: 'Médico criado com sucesso',
      id: result.insertId
    });
  });
};

exports.atualizarMedico = (req, res) => {
  const { id } = req.params;
  const { nome, especialidade } = req.body;

  if (!nome || !especialidade) {
    return res.status(400).json({ erro: 'Preencha nome e especialidade' });
  }

  const sql = 'UPDATE medicos SET nome = ?, especialidade = ? WHERE id = ?';

  db.query(sql, [nome, especialidade, id], (err, result) => {
    if (err) {
      console.error('Erro ao atualizar médico:', err);
      return res.status(500).json({ erro: 'Erro ao atualizar médico' });
    }

    if (result.affectedRows === 0) {
      return res.status(404).json({ erro: 'Médico não encontrado' });
    }

    res.json({ mensagem: 'Médico atualizado com sucesso' });
  });
};

exports.excluirMedico = (req, res) => {
  const { id } = req.params;

  const sql = 'DELETE FROM medicos WHERE id = ?';

  db.query(sql, [id], (err, result) => {
    if (err) {
      console.error('Erro ao excluir médico:', err);
      return res.status(500).json({ erro: 'Erro ao excluir médico' });
    }

    if (result.affectedRows === 0) {
      return res.status(404).json({ erro: 'Médico não encontrado' });
    }

    res.json({ mensagem: 'Médico excluído com sucesso' });
  });
};