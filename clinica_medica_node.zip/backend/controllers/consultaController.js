const db = require('../config/db');

exports.listarConsultas = (req, res) => {
  const sql = `
    SELECT 
      c.id,
      c.paciente_id,
      c.medico_id,
      c.data,
      c.descricao,
      p.nome AS paciente_nome,
      m.nome AS medico_nome
    FROM consultas c
    LEFT JOIN pacientes p ON c.paciente_id = p.id
    LEFT JOIN medicos m ON c.medico_id = m.id
    ORDER BY c.id DESC
  `;

  db.query(sql, (err, results) => {
    if (err) {
      console.error('Erro ao listar consultas:', err);
      return res.status(500).json({ erro: 'Erro ao listar consultas' });
    }

    res.json(results);
  });
};

exports.criarConsulta = (req, res) => {
  const { paciente_id, medico_id, data, descricao } = req.body;

  if (!paciente_id || !medico_id || !data || !descricao) {
    return res.status(400).json({ erro: 'Preencha paciente, médico, data e descrição' });
  }

  const sql = `
    INSERT INTO consultas (paciente_id, medico_id, data, descricao)
    VALUES (?, ?, ?, ?)
  `;

  db.query(sql, [paciente_id, medico_id, data, descricao], (err, result) => {
    if (err) {
      console.error('Erro ao criar consulta:', err);
      return res.status(500).json({ erro: 'Erro ao criar consulta' });
    }

    res.status(201).json({
      mensagem: 'Consulta criada com sucesso',
      id: result.insertId
    });
  });
};

exports.atualizarConsulta = (req, res) => {
  const { id } = req.params;
  const { paciente_id, medico_id, data, descricao } = req.body;

  if (!paciente_id || !medico_id || !data || !descricao) {
    return res.status(400).json({ erro: 'Preencha paciente, médico, data e descrição' });
  }

  const sql = `
    UPDATE consultas
    SET paciente_id = ?, medico_id = ?, data = ?, descricao = ?
    WHERE id = ?
  `;

  db.query(sql, [paciente_id, medico_id, data, descricao, id], (err, result) => {
    if (err) {
      console.error('Erro ao atualizar consulta:', err);
      return res.status(500).json({ erro: 'Erro ao atualizar consulta' });
    }

    if (result.affectedRows === 0) {
      return res.status(404).json({ erro: 'Consulta não encontrada' });
    }

    res.json({ mensagem: 'Consulta atualizada com sucesso' });
  });
};

exports.excluirConsulta = (req, res) => {
  const { id } = req.params;

  const sql = 'DELETE FROM consultas WHERE id = ?';

  db.query(sql, [id], (err, result) => {
    if (err) {
      console.error('Erro ao excluir consulta:', err);
      return res.status(500).json({ erro: 'Erro ao excluir consulta' });
    }

    if (result.affectedRows === 0) {
      return res.status(404).json({ erro: 'Consulta não encontrada' });
    }

    res.json({ mensagem: 'Consulta excluída com sucesso' });
  });
};