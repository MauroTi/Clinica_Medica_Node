const API_BASE = 'http://localhost:3000/api';

const estado = {
  pacientes: [],
  medicos: [],
  consultas: [],
  edicao: {
    pacienteId: null,
    medicoId: null,
    consultaId: null
  },
  filtros: {
    pacientes: {
      busca: localStorage.getItem('filtro_paciente_busca') || '',
      ordenacao: localStorage.getItem('filtro_paciente_ordenacao') || 'nome-asc'
    },
    medicos: {
      busca: localStorage.getItem('filtro_medico_busca') || '',
      ordenacao: localStorage.getItem('filtro_medico_ordenacao') || 'nome-asc'
    },
    consultas: {
      busca: localStorage.getItem('filtro_consulta_busca') || '',
      ordenacao: localStorage.getItem('filtro_consulta_ordenacao') || 'data-asc'
    }
  }
};

// =========================
// ELEMENTOS
// =========================
const tabs = document.querySelectorAll('.tab-btn');
const tabContents = document.querySelectorAll('.tab-content');

const totalPacientes = document.getElementById('totalPacientes');
const totalMedicos = document.getElementById('totalMedicos');
const totalConsultas = document.getElementById('totalConsultas');

const formPaciente = document.getElementById('formPaciente');
const nomePaciente = document.getElementById('nomePaciente');
const idadePaciente = document.getElementById('idadePaciente');
const telefonePaciente = document.getElementById('telefonePaciente');
const btnSalvarPaciente = document.getElementById('btnSalvarPaciente');
const btnCancelarEdicaoPaciente = document.getElementById('btnCancelarEdicaoPaciente');
const modoPaciente = document.getElementById('modoPaciente');
const listaPacientes = document.getElementById('listaPacientes');
const buscaPaciente = document.getElementById('buscaPaciente');
const ordenacaoPaciente = document.getElementById('ordenacaoPaciente');
const limparFiltroPaciente = document.getElementById('limparFiltroPaciente');

const formMedico = document.getElementById('formMedico');
const nomeMedico = document.getElementById('nomeMedico');
const especialidadeMedico = document.getElementById('especialidadeMedico');
const btnSalvarMedico = document.getElementById('btnSalvarMedico');
const btnCancelarEdicaoMedico = document.getElementById('btnCancelarEdicaoMedico');
const modoMedico = document.getElementById('modoMedico');
const listaMedicos = document.getElementById('listaMedicos');
const buscaMedico = document.getElementById('buscaMedico');
const ordenacaoMedico = document.getElementById('ordenacaoMedico');
const limparFiltroMedico = document.getElementById('limparFiltroMedico');

const formConsulta = document.getElementById('formConsulta');
const pacienteConsulta = document.getElementById('pacienteConsulta');
const medicoConsulta = document.getElementById('medicoConsulta');
const dataConsulta = document.getElementById('dataConsulta');
const descricaoConsulta = document.getElementById('descricaoConsulta');
const btnSalvarConsulta = document.getElementById('btnSalvarConsulta');
const btnCancelarEdicaoConsulta = document.getElementById('btnCancelarEdicaoConsulta');
const modoConsulta = document.getElementById('modoConsulta');
const listaConsultas = document.getElementById('listaConsultas');
const buscaConsulta = document.getElementById('buscaConsulta');
const ordenacaoConsulta = document.getElementById('ordenacaoConsulta');
const limparFiltroConsulta = document.getElementById('limparFiltroConsulta');

const toastContainer = document.getElementById('toastContainer');

// =========================
// UTILITÁRIOS
// =========================
function mostrarToast(mensagem, tipo = 'success') {
  const toast = document.createElement('div');
  toast.className = `toast ${tipo}`;
  toast.textContent = mensagem;
  toastContainer.appendChild(toast);

  setTimeout(() => {
    toast.remove();
  }, 3000);
}

function salvarFiltro(chave, valor) {
  localStorage.setItem(chave, valor);
}

function formatarData(dataISO) {
  if (!dataISO) return '-';
  const data = new Date(dataISO);
  if (isNaN(data.getTime())) return dataISO;
  return data.toLocaleDateString('pt-BR');
}

function obterNomePaciente(item) {
  if (item.paciente_nome) return item.paciente_nome;
  if (item.nome_paciente) return item.nome_paciente;
  const paciente = estado.pacientes.find(p => p.id == item.paciente_id);
  return paciente ? paciente.nome : `ID ${item.paciente_id}`;
}

function obterNomeMedico(item) {
  if (item.medico_nome) return item.medico_nome;
  if (item.nome_medico) return item.nome_medico;
  const medico = estado.medicos.find(m => m.id == item.medico_id);
  return medico ? medico.nome : `ID ${item.medico_id}`;
}

// =========================
// TABS + PERSISTÊNCIA
// =========================
function ativarTab(tabName) {
  tabs.forEach(btn => {
    btn.classList.toggle('active', btn.dataset.tab === tabName);
  });

  tabContents.forEach(content => {
    content.classList.toggle('active', content.id === `tab-${tabName}`);
  });

  localStorage.setItem('aba_ativa_clinica', tabName);
}

tabs.forEach(btn => {
  btn.addEventListener('click', () => {
    ativarTab(btn.dataset.tab);
  });
});

function restaurarTabAtiva() {
  const abaSalva = localStorage.getItem('aba_ativa_clinica') || 'pacientes';
  ativarTab(abaSalva);
}

// =========================
// API
// =========================
async function apiFetch(url, options = {}) {
  const response = await fetch(url, options);

  if (!response.ok) {
    let erro = 'Erro na requisição';
    try {
      const data = await response.json();
      erro = data.erro || data.message || erro;
    } catch {
      // ignora
    }
    throw new Error(erro);
  }

  if (response.status === 204) return null;
  return response.json();
}

// =========================
// PACIENTES
// =========================
async function carregarPacientes() {
  estado.pacientes = await apiFetch(`${API_BASE}/pacientes`);
  atualizarDashboard();
  preencherSelectPacientes();
  renderizarPacientes();
}

function preencherSelectPacientes() {
  const valorAtual = pacienteConsulta.value;

  pacienteConsulta.innerHTML = '<option value="">Selecione o paciente</option>';

  estado.pacientes.forEach(paciente => {
    const option = document.createElement('option');
    option.value = paciente.id;
    option.textContent = `${paciente.nome} (ID ${paciente.id})`;
    pacienteConsulta.appendChild(option);
  });

  if ([...pacienteConsulta.options].some(opt => opt.value === valorAtual)) {
    pacienteConsulta.value = valorAtual;
  }
}

function obterPacientesFiltrados() {
  let lista = [...estado.pacientes];
  const busca = estado.filtros.pacientes.busca.toLowerCase().trim();
  const ordenacao = estado.filtros.pacientes.ordenacao;

  if (busca) {
    lista = lista.filter(p =>
      (p.nome || '').toLowerCase().includes(busca) ||
      String(p.telefone || '').toLowerCase().includes(busca)
    );
  }

  switch (ordenacao) {
    case 'nome-asc':
      lista.sort((a, b) => a.nome.localeCompare(b.nome));
      break;
    case 'nome-desc':
      lista.sort((a, b) => b.nome.localeCompare(a.nome));
      break;
    case 'idade-asc':
      lista.sort((a, b) => Number(a.idade) - Number(b.idade));
      break;
    case 'idade-desc':
      lista.sort((a, b) => Number(b.idade) - Number(a.idade));
      break;
  }

  return lista;
}

function renderizarPacientes() {
  const pacientes = obterPacientesFiltrados();
  listaPacientes.innerHTML = '';

  if (!pacientes.length) {
    listaPacientes.innerHTML = `
      <tr>
        <td colspan="5" class="vazio">Nenhum paciente encontrado.</td>
      </tr>
    `;
    return;
  }

  pacientes.forEach(paciente => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${paciente.id}</td>
      <td>${paciente.nome}</td>
      <td>${paciente.idade}</td>
      <td>${paciente.telefone}</td>
      <td>
        <div class="acoes">
          <button class="btn-editar" data-id="${paciente.id}" data-tipo="paciente">Editar</button>
          <button class="btn-excluir" data-id="${paciente.id}" data-tipo="paciente">Excluir</button>
        </div>
      </td>
    `;
    listaPacientes.appendChild(tr);
  });
}

function entrarModoEdicaoPaciente(paciente) {
  estado.edicao.pacienteId = paciente.id;
  nomePaciente.value = paciente.nome;
  idadePaciente.value = paciente.idade;
  telefonePaciente.value = paciente.telefone;

  btnSalvarPaciente.textContent = 'Atualizar paciente';
  btnCancelarEdicaoPaciente.classList.remove('hidden');
  modoPaciente.textContent = `Modo: Edição (ID ${paciente.id})`;

  ativarTab('pacientes');
}

function sairModoEdicaoPaciente() {
  estado.edicao.pacienteId = null;
  formPaciente.reset();
  btnSalvarPaciente.textContent = 'Salvar paciente';
  btnCancelarEdicaoPaciente.classList.add('hidden');
  modoPaciente.textContent = 'Modo: Cadastro';
}

async function salvarPaciente(event) {
  event.preventDefault();

  const payload = {
    nome: nomePaciente.value.trim(),
    idade: Number(idadePaciente.value),
    telefone: telefonePaciente.value.trim()
  };

  try {
    if (estado.edicao.pacienteId) {
      await apiFetch(`${API_BASE}/pacientes/${estado.edicao.pacienteId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      mostrarToast('Paciente atualizado com sucesso!');
    } else {
      await apiFetch(`${API_BASE}/pacientes`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      mostrarToast('Paciente cadastrado com sucesso!');
    }

    sairModoEdicaoPaciente();
    await carregarPacientes();
    await carregarConsultas();
  } catch (error) {
    mostrarToast(error.message, 'error');
  }
}

async function excluirPaciente(id) {
  const confirmar = confirm(`Deseja realmente excluir o paciente ID ${id}?`);
  if (!confirmar) return;

  try {
    await apiFetch(`${API_BASE}/pacientes/${id}`, {
      method: 'DELETE'
    });

    if (estado.edicao.pacienteId == id) {
      sairModoEdicaoPaciente();
    }

    mostrarToast('Paciente excluído com sucesso!', 'warning');
    await carregarPacientes();
    await carregarConsultas();
  } catch (error) {
    mostrarToast(error.message, 'error');
  }
}

// =========================
// MÉDICOS
// =========================
async function carregarMedicos() {
  estado.medicos = await apiFetch(`${API_BASE}/medicos`);
  atualizarDashboard();
  preencherSelectMedicos();
  renderizarMedicos();
}

function preencherSelectMedicos() {
  const valorAtual = medicoConsulta.value;

  medicoConsulta.innerHTML = '<option value="">Selecione o médico</option>';

  estado.medicos.forEach(medico => {
    const option = document.createElement('option');
    option.value = medico.id;
    option.textContent = `${medico.nome} (ID ${medico.id})`;
    medicoConsulta.appendChild(option);
  });

  if ([...medicoConsulta.options].some(opt => opt.value === valorAtual)) {
    medicoConsulta.value = valorAtual;
  }
}

function obterMedicosFiltrados() {
  let lista = [...estado.medicos];
  const busca = estado.filtros.medicos.busca.toLowerCase().trim();
  const ordenacao = estado.filtros.medicos.ordenacao;

  if (busca) {
    lista = lista.filter(m =>
      (m.nome || '').toLowerCase().includes(busca) ||
      (m.especialidade || '').toLowerCase().includes(busca)
    );
  }

  switch (ordenacao) {
    case 'nome-asc':
      lista.sort((a, b) => a.nome.localeCompare(b.nome));
      break;
    case 'nome-desc':
      lista.sort((a, b) => b.nome.localeCompare(a.nome));
      break;
    case 'esp-asc':
      lista.sort((a, b) => (a.especialidade || '').localeCompare(b.especialidade || ''));
      break;
    case 'esp-desc':
      lista.sort((a, b) => (b.especialidade || '').localeCompare(a.especialidade || ''));
      break;
  }

  return lista;
}

function renderizarMedicos() {
  const medicos = obterMedicosFiltrados();
  listaMedicos.innerHTML = '';

  if (!medicos.length) {
    listaMedicos.innerHTML = `
      <tr>
        <td colspan="4" class="vazio">Nenhum médico encontrado.</td>
      </tr>
    `;
    return;
  }

  medicos.forEach(medico => {
    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${medico.id}</td>
      <td>${medico.nome}</td>
      <td>${medico.especialidade}</td>
      <td>
        <div class="acoes">
          <button class="btn-editar" data-id="${medico.id}" data-tipo="medico">Editar</button>
          <button class="btn-excluir" data-id="${medico.id}" data-tipo="medico">Excluir</button>
        </div>
      </td>
    `;
    listaMedicos.appendChild(tr);
  });
}

function entrarModoEdicaoMedico(medico) {
  estado.edicao.medicoId = medico.id;
  nomeMedico.value = medico.nome;
  especialidadeMedico.value = medico.especialidade;

  btnSalvarMedico.textContent = 'Atualizar médico';
  btnCancelarEdicaoMedico.classList.remove('hidden');
  modoMedico.textContent = `Modo: Edição (ID ${medico.id})`;

  ativarTab('medicos');
}

function sairModoEdicaoMedico() {
  estado.edicao.medicoId = null;
  formMedico.reset();
  btnSalvarMedico.textContent = 'Salvar médico';
  btnCancelarEdicaoMedico.classList.add('hidden');
  modoMedico.textContent = 'Modo: Cadastro';
}

async function salvarMedico(event) {
  event.preventDefault();

  const payload = {
    nome: nomeMedico.value.trim(),
    especialidade: especialidadeMedico.value.trim()
  };

  try {
    if (estado.edicao.medicoId) {
      await apiFetch(`${API_BASE}/medicos/${estado.edicao.medicoId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      mostrarToast('Médico atualizado com sucesso!');
    } else {
      await apiFetch(`${API_BASE}/medicos`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      mostrarToast('Médico cadastrado com sucesso!');
    }

    sairModoEdicaoMedico();
    await carregarMedicos();
    await carregarConsultas();
  } catch (error) {
    mostrarToast(error.message, 'error');
  }
}

async function excluirMedico(id) {
  const confirmar = confirm(`Deseja realmente excluir o médico ID ${id}?`);
  if (!confirmar) return;

  try {
    await apiFetch(`${API_BASE}/medicos/${id}`, {
      method: 'DELETE'
    });

    if (estado.edicao.medicoId == id) {
      sairModoEdicaoMedico();
    }

    mostrarToast('Médico excluído com sucesso!', 'warning');
    await carregarMedicos();
    await carregarConsultas();
  } catch (error) {
    mostrarToast(error.message, 'error');
  }
}

// =========================
// CONSULTAS
// =========================
async function carregarConsultas() {
  estado.consultas = await apiFetch(`${API_BASE}/consultas`);
  atualizarDashboard();
  renderizarConsultas();
}

function obterConsultasFiltradas() {
  let lista = [...estado.consultas];
  const busca = estado.filtros.consultas.busca.toLowerCase().trim();
  const ordenacao = estado.filtros.consultas.ordenacao;

  if (busca) {
    lista = lista.filter(c => {
      const nomePaciente = obterNomePaciente(c).toLowerCase();
      const nomeMedico = obterNomeMedico(c).toLowerCase();
      const descricao = (c.descricao || '').toLowerCase();

      return (
        nomePaciente.includes(busca) ||
        nomeMedico.includes(busca) ||
        descricao.includes(busca)
      );
    });
  }

  switch (ordenacao) {
    case 'data-asc':
      lista.sort((a, b) => {
        const dataA = a.data_consulta || a.data || '';
        const dataB = b.data_consulta || b.data || '';
        return new Date(dataA) - new Date(dataB);
      });
      break;
    case 'data-desc':
      lista.sort((a, b) => {
        const dataA = a.data_consulta || a.data || '';
        const dataB = b.data_consulta || b.data || '';
        return new Date(dataB) - new Date(dataA);
      });
      break;
    case 'paciente-asc':
      lista.sort((a, b) => obterNomePaciente(a).localeCompare(obterNomePaciente(b)));
      break;
    case 'medico-asc':
      lista.sort((a, b) => obterNomeMedico(a).localeCompare(obterNomeMedico(b)));
      break;
  }

  return lista;
}

function renderizarConsultas() {
  const consultas = obterConsultasFiltradas();
  listaConsultas.innerHTML = '';

  if (!consultas.length) {
    listaConsultas.innerHTML = `
      <tr>
        <td colspan="6" class="vazio">Nenhuma consulta encontrada.</td>
      </tr>
    `;
    return;
  }

  consultas.forEach(consulta => {
    const dataConsultaFormatada = consulta.data_consulta || consulta.data || '';

    const tr = document.createElement('tr');
    tr.innerHTML = `
      <td>${consulta.id}</td>
      <td>${obterNomePaciente(consulta)}</td>
      <td>${obterNomeMedico(consulta)}</td>
      <td>${formatarData(dataConsultaFormatada)}</td>
      <td>${consulta.descricao || '-'}</td>
      <td>
        <div class="acoes">
          <button class="btn-editar" data-id="${consulta.id}" data-tipo="consulta">Editar</button>
          <button class="btn-excluir" data-id="${consulta.id}" data-tipo="consulta">Excluir</button>
        </div>
      </td>
    `;
    listaConsultas.appendChild(tr);
  });
}

function entrarModoEdicaoConsulta(consulta) {
  estado.edicao.consultaId = consulta.id;

  pacienteConsulta.value = String(consulta.paciente_id);
  medicoConsulta.value = String(consulta.medico_id);

  const dataConsultaValor = consulta.data_consulta || consulta.data || '';
  const dataAjustada = dataConsultaValor ? new Date(dataConsultaValor).toISOString().split('T')[0] : '';
  dataConsulta.value = dataAjustada;

  descricaoConsulta.value = consulta.descricao || '';

  btnSalvarConsulta.textContent = 'Atualizar consulta';
  btnCancelarEdicaoConsulta.classList.remove('hidden');
  modoConsulta.textContent = `Modo: Edição (ID ${consulta.id})`;

  ativarTab('consultas');
}

function sairModoEdicaoConsulta() {
  estado.edicao.consultaId = null;
  formConsulta.reset();
  btnSalvarConsulta.textContent = 'Salvar consulta';
  btnCancelarEdicaoConsulta.classList.add('hidden');
  modoConsulta.textContent = 'Modo: Cadastro';
}

async function salvarConsulta(event) {
  event.preventDefault();

  const payload = {
    paciente_id: Number(pacienteConsulta.value),
    medico_id: Number(medicoConsulta.value),
    data_consulta: dataConsulta.value,
    descricao: descricaoConsulta.value.trim()
  };

  try {
    if (estado.edicao.consultaId) {
      await apiFetch(`${API_BASE}/consultas/${estado.edicao.consultaId}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      mostrarToast('Consulta atualizada com sucesso!');
    } else {
      await apiFetch(`${API_BASE}/consultas`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      mostrarToast('Consulta cadastrada com sucesso!');
    }

    sairModoEdicaoConsulta();
    await carregarConsultas();
  } catch (error) {
    mostrarToast(error.message, 'error');
  }
}

async function excluirConsulta(id) {
  const confirmar = confirm(`Deseja realmente excluir a consulta ID ${id}?`);
  if (!confirmar) return;

  try {
    await apiFetch(`${API_BASE}/consultas/${id}`, {
      method: 'DELETE'
    });

    if (estado.edicao.consultaId == id) {
      sairModoEdicaoConsulta();
    }

    mostrarToast('Consulta excluída com sucesso!', 'warning');
    await carregarConsultas();
  } catch (error) {
    mostrarToast(error.message, 'error');
  }
}

// =========================
// DASHBOARD
// =========================
function atualizarDashboard() {
  totalPacientes.textContent = estado.pacientes.length;
  totalMedicos.textContent = estado.medicos.length;
  totalConsultas.textContent = estado.consultas.length;
}

// =========================
// EVENTOS DE AÇÕES NAS TABELAS
// =========================
document.addEventListener('click', async (event) => {
  const botao = event.target.closest('button[data-id][data-tipo]');
  if (!botao) return;

  const id = Number(botao.dataset.id);
  const tipo = botao.dataset.tipo;
  const acao = botao.classList.contains('btn-editar') ? 'editar' : 'excluir';

  if (tipo === 'paciente') {
    if (acao === 'editar') {
      const paciente = estado.pacientes.find(p => p.id === id);
      if (paciente) entrarModoEdicaoPaciente(paciente);
    } else {
      await excluirPaciente(id);
    }
  }

  if (tipo === 'medico') {
    if (acao === 'editar') {
      const medico = estado.medicos.find(m => m.id === id);
      if (medico) entrarModoEdicaoMedico(medico);
    } else {
      await excluirMedico(id);
    }
  }

  if (tipo === 'consulta') {
    if (acao === 'editar') {
      const consulta = estado.consultas.find(c => c.id === id);
      if (consulta) entrarModoEdicaoConsulta(consulta);
    } else {
      await excluirConsulta(id);
    }
  }
});

// =========================
// EVENTOS FORMULÁRIOS
// =========================
formPaciente.addEventListener('submit', salvarPaciente);
btnCancelarEdicaoPaciente.addEventListener('click', sairModoEdicaoPaciente);

formMedico.addEventListener('submit', salvarMedico);
btnCancelarEdicaoMedico.addEventListener('click', sairModoEdicaoMedico);

formConsulta.addEventListener('submit', salvarConsulta);
btnCancelarEdicaoConsulta.addEventListener('click', sairModoEdicaoConsulta);

// =========================
// FILTROS PACIENTES
// =========================
buscaPaciente.value = estado.filtros.pacientes.busca;
ordenacaoPaciente.value = estado.filtros.pacientes.ordenacao;

buscaPaciente.addEventListener('input', () => {
  estado.filtros.pacientes.busca = buscaPaciente.value;
  salvarFiltro('filtro_paciente_busca', buscaPaciente.value);
  renderizarPacientes();
});

ordenacaoPaciente.addEventListener('change', () => {
  estado.filtros.pacientes.ordenacao = ordenacaoPaciente.value;
  salvarFiltro('filtro_paciente_ordenacao', ordenacaoPaciente.value);
  renderizarPacientes();
});

limparFiltroPaciente.addEventListener('click', () => {
  estado.filtros.pacientes.busca = '';
  estado.filtros.pacientes.ordenacao = 'nome-asc';
  buscaPaciente.value = '';
  ordenacaoPaciente.value = 'nome-asc';
  salvarFiltro('filtro_paciente_busca', '');
  salvarFiltro('filtro_paciente_ordenacao', 'nome-asc');
  renderizarPacientes();
  mostrarToast('Filtros de pacientes limpos!', 'warning');
});

// =========================
// FILTROS MÉDICOS
// =========================
buscaMedico.value = estado.filtros.medicos.busca;
ordenacaoMedico.value = estado.filtros.medicos.ordenacao;

buscaMedico.addEventListener('input', () => {
  estado.filtros.medicos.busca = buscaMedico.value;
  salvarFiltro('filtro_medico_busca', buscaMedico.value);
  renderizarMedicos();
});

ordenacaoMedico.addEventListener('change', () => {
  estado.filtros.medicos.ordenacao = ordenacaoMedico.value;
  salvarFiltro('filtro_medico_ordenacao', ordenacaoMedico.value);
  renderizarMedicos();
});

limparFiltroMedico.addEventListener('click', () => {
  estado.filtros.medicos.busca = '';
  estado.filtros.medicos.ordenacao = 'nome-asc';
  buscaMedico.value = '';
  ordenacaoMedico.value = 'nome-asc';
  salvarFiltro('filtro_medico_busca', '');
  salvarFiltro('filtro_medico_ordenacao', 'nome-asc');
  renderizarMedicos();
  mostrarToast('Filtros de médicos limpos!', 'warning');
});

// =========================
// FILTROS CONSULTAS
// =========================
buscaConsulta.value = estado.filtros.consultas.busca;
ordenacaoConsulta.value = estado.filtros.consultas.ordenacao;

buscaConsulta.addEventListener('input', () => {
  estado.filtros.consultas.busca = buscaConsulta.value;
  salvarFiltro('filtro_consulta_busca', buscaConsulta.value);
  renderizarConsultas();
});

ordenacaoConsulta.addEventListener('change', () => {
  estado.filtros.consultas.ordenacao = ordenacaoConsulta.value;
  salvarFiltro('filtro_consulta_ordenacao', ordenacaoConsulta.value);
  renderizarConsultas();
});

limparFiltroConsulta.addEventListener('click', () => {
  estado.filtros.consultas.busca = '';
  estado.filtros.consultas.ordenacao = 'data-asc';
  buscaConsulta.value = '';
  ordenacaoConsulta.value = 'data-asc';
  salvarFiltro('filtro_consulta_busca', '');
  salvarFiltro('filtro_consulta_ordenacao', 'data-asc');
  renderizarConsultas();
  mostrarToast('Filtros de consultas limpos!', 'warning');
});

// =========================
// INICIALIZAÇÃO
// =========================
async function inicializar() {
  try {
    restaurarTabAtiva();

    await carregarPacientes();
    await carregarMedicos();
    await carregarConsultas();

    mostrarToast('Sistema carregado com sucesso!');
  } catch (error) {
    console.error(error);
    mostrarToast(`Erro ao inicializar: ${error.message}`, 'error');
  }
}

inicializar();